import React from 'react';
import { FadeUp } from '../components/Animations';

const About: React.FC = () => {
  return (
    <div className="bg-page">
      {/* HERO AREA */}
      <section className="pt-[140px] pb-20 text-center px-6">
        <FadeUp>
          <h1 className="text-[3rem] font-bold text-white mb-4">About the Assistant</h1>
          <p className="text-[1.25rem] text-text-secondary">Why this AI assistant was built</p>
        </FadeUp>
      </section>

      {/* CONTENT SECTION */}
      <section className="py-20 px-6">
        <div className="max-w-[1000px] mx-auto grid md:grid-cols-[40%_60%] gap-16 items-start">
          {/* LEFT: Image */}
          <FadeUp delay={0.2}>
            <div className="w-full aspect-[3/4] bg-white/[0.02] border-2 border-dashed border-gold/30 rounded-2xl flex items-center justify-center shadow-[0_0_60px_rgba(212,175,55,0.1)]">
              <span className="text-white/30">Product Shot</span>
            </div>
          </FadeUp>

          {/* RIGHT: Bio */}
          <FadeUp delay={0.3}>
            <h2 className="text-[2rem] font-semibold text-white mb-6">Built for Usability & Privacy</h2>
            
            <p className="text-[1.125rem] text-white/70 leading-[1.8] mb-5">
              We built this AI assistant with a single goal: to provide a truly personal, reliable, and secure AI companion. In a world of generic chatbots, our focus is on usability that fits into your actual daily workflow.
            </p>

            <p className="text-[1.125rem] text-white/70 leading-[1.8] mb-8">
              Reliability and privacy are at the core of our vision. This assistant doesn't just chat; it remembers your context, respects your privacy, and executes tasks precisely when you need them.
            </p>

            {/* Badges */}
            <div className="flex flex-wrap gap-4">
              {["Privacy First", "High Availability", "Smart Context"].map((badge, idx) => (
                <span key={idx} className="bg-gold-dim border border-gold/30 text-gold text-[0.75rem] font-medium px-4 py-2 rounded-md uppercase tracking-[0.05em]">
                  {badge}
                </span>
              ))}
            </div>
          </FadeUp>
        </div>
      </section>
    </div>
  );
};

export default About;