import React from 'react';
import { FadeUp } from '../components/Animations';

const Contact: React.FC = () => {
  return (
    <div className="bg-page">
      <section className="pt-[160px] pb-[160px] px-6">
        <div className="max-w-[500px] mx-auto">
          <FadeUp>
            <div className="text-center">
              <h1 className="text-[2.5rem] font-semibold text-white mb-4">Get in Touch</h1>
              <p className="text-[1rem] text-text-secondary mb-10">Have a question or need support? Send us a message.</p>
            </div>

            <form onSubmit={(e) => e.preventDefault()} className="text-left">
              <div className="mb-5">
                <label className="block text-[0.875rem] text-white/80 mb-2">Name</label>
                <input type="text" className="w-full bg-white/[0.03] border border-white/10 rounded-lg px-4 py-[14px] text-white text-[1rem] focus:outline-none focus:border-gold focus:ring-4 focus:ring-gold/20 transition-all" />
              </div>

              <div className="mb-5">
                <label className="block text-[0.875rem] text-white/80 mb-2">Email</label>
                <input type="email" className="w-full bg-white/[0.03] border border-white/10 rounded-lg px-4 py-[14px] text-white text-[1rem] focus:outline-none focus:border-gold focus:ring-4 focus:ring-gold/20 transition-all" />
              </div>

              <div className="mb-6">
                <label className="block text-[0.875rem] text-white/80 mb-2">Message</label>
                <textarea className="w-full min-h-[150px] resize-y bg-white/[0.03] border border-white/10 rounded-lg px-4 py-[14px] text-white text-[1rem] focus:outline-none focus:border-gold focus:ring-4 focus:ring-gold/20 transition-all"></textarea>
              </div>

              <button className="w-full bg-gold text-page font-semibold py-[14px] rounded-lg text-[1rem] hover:shadow-[0_0_30px_rgba(212,175,55,0.4)] transition-all">
                Send Message
              </button>

              <div className="mt-6 text-center text-[0.875rem] text-white/50">
                Or email directly: <a href="mailto:support@aiassistant.com" className="text-gold hover:underline">support@aiassistant.com</a>
              </div>
            </form>
          </FadeUp>
        </div>
      </section>
    </div>
  );
};

export default Contact;