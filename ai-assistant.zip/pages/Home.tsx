import React, { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FadeUp, HoverLift } from '../components/Animations';

const Home: React.FC = () => {
  const { hash } = useLocation();

  useEffect(() => {
    if (hash) {
      const element = document.getElementById(hash.replace('#', ''));
      if (element) {
        setTimeout(() => {
          element.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    }
  }, [hash]);

  return (
    <>
      {/* SECTION 2: HERO */}
      <section className="min-h-screen pt-[120px] pb-20 bg-page relative overflow-hidden flex items-center transition-colors duration-300">
        <div className="max-w-[1200px] mx-auto px-6 w-full">
          
          {/* LEFT COLUMN */}
          <FadeUp>
            {/* Badge */}
            <div className="inline-block px-4 py-2 mb-6 rounded-full border border-gold/50 bg-gold-dim">
              <span className="text-[0.75rem] font-medium tracking-[0.1em] uppercase text-gold">
                INTELLIGENT AI ASSISTANT
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-[2.5rem] lg:text-[4.5rem] font-bold tracking-[-0.02em] leading-[1.1] mb-6 text-text-primary">
              Your Personal <span className="text-gold">AI</span> That Actually Works
            </h1>

            {/* Subheadline */}
            <p className="text-[1rem] lg:text-[1.25rem] text-text-secondary leading-[1.6] max-w-[540px] mb-6">
              A smart, JARVIS-style AI assistant designed to automate tasks, answer questions, and help you work faster every day.
            </p>

            {/* Stats */}
            <p className="text-[0.875rem] text-text-secondary mb-8">
              24/7 Availability <span className="text-gold mx-1">•</span> Secure by Design <span className="text-gold mx-1">•</span> Built for Real Users
            </p>

            {/* Button Group */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/register" className="bg-gold text-page font-semibold px-8 py-4 rounded-lg text-center hover:shadow-[0_0_30px_rgba(212,175,55,0.4)] transition-all duration-300">
                Start Using AI
              </Link>
              <button className="bg-transparent border border-gold text-gold font-semibold px-8 py-4 rounded-lg hover:bg-gold-dim transition-all duration-300">
                Watch Demo
              </button>
            </div>
          </FadeUp>
        </div>
      </section>

      {/* SECTION 3: FEATURES */}
      <section id="features" className="py-[120px] bg-page relative transition-colors duration-300">
        <div className="max-w-[1200px] mx-auto px-6">
          <FadeUp>
            <div className="text-center mb-12">
              <h2 className="text-[2.5rem] font-semibold text-text-primary">Features</h2>
              <div className="w-[60px] h-[3px] bg-gold mx-auto mt-4 mb-12"></div>
            </div>
          </FadeUp>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-[900px] mx-auto">
            {[
              {
                tag: "VOICE & TEXT",
                title: "Voice & Text Commands",
                desc: "Control your AI assistant using natural voice or text commands.",
                meta: "Natural Language Processing",
                price: "Included"
              },
              {
                tag: "AUTOMATION",
                title: "Task Automation",
                desc: "Automate repetitive tasks and workflows effortlessly.",
                meta: "Workflow Engine",
                price: "Pro"
              },
              {
                tag: "INTELLIGENCE",
                title: "Smart Answers",
                desc: "Get accurate answers using real-time knowledge and memory.",
                meta: "Real-time Search",
                price: "Pro"
              },
              {
                tag: "PERSONALIZATION",
                title: "Custom Commands & Memory",
                desc: "Teach your AI custom commands and let it remember your preferences.",
                meta: "Memory Module",
                price: "Enterprise"
              }
            ].map((feature, idx) => (
              <FadeUp key={idx} delay={idx * 0.1}>
                <HoverLift className="h-full bg-surface border border-border rounded-2xl p-8 hover:border-gold/40 hover:shadow-[0_0_40px_rgba(212,175,55,0.15)] transition-all duration-300 flex flex-col group">
                  <span className="text-[0.875rem] font-medium uppercase tracking-[0.05em] text-gold">{feature.tag}</span>
                  <h3 className="text-[1.5rem] font-semibold text-text-primary mt-3">{feature.title}</h3>
                  <p className="text-[1rem] text-text-secondary leading-[1.6] mt-3 flex-grow">{feature.desc}</p>
                  <div className="text-[0.875rem] text-text-tertiary mt-4">{feature.meta}</div>
                  <div className="text-[1.75rem] font-bold text-gold mt-4">{feature.price}</div>
                  <a href="#" className="text-gold font-medium mt-4 hover:underline block">Learn More →</a>
                </HoverLift>
              </FadeUp>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 4: ABOUT (Integrated) */}
      <section id="about" className="py-[120px] bg-surface transition-colors duration-300">
        <div className="max-w-[1200px] mx-auto px-6">
          <FadeUp>
             <div className="text-center mb-16">
              <h2 className="text-[2.5rem] font-semibold text-text-primary">About Aris</h2>
              <div className="w-[60px] h-[3px] bg-gold mx-auto mt-4 mb-12"></div>
            </div>
          </FadeUp>
          
          <div className="grid md:grid-cols-[40%_60%] gap-16 items-center">
             {/* LEFT: Image */}
            <FadeUp delay={0.2}>
              <div className="w-full aspect-[3/4] bg-page border-2 border-dashed border-gold/30 rounded-2xl flex items-center justify-center shadow-[0_0_60px_rgba(212,175,55,0.1)]">
                <span className="text-text-tertiary">AI Interface Visual</span>
              </div>
            </FadeUp>

            {/* RIGHT: Bio */}
            <FadeUp delay={0.3}>
              <h3 className="text-[2rem] font-semibold text-text-primary mb-6">Built for Usability & Privacy</h3>
              
              <p className="text-[1.125rem] text-text-secondary leading-[1.8] mb-5">
                We built Aris with a single goal: to provide a truly personal, reliable, and secure AI companion. In a world of generic chatbots, our focus is on usability that fits into your actual daily workflow.
              </p>

              <p className="text-[1.125rem] text-text-secondary leading-[1.8] mb-8">
                Reliability and privacy are at the core of our vision. Aris doesn't just chat; it remembers your context, respects your privacy, and executes tasks precisely when you need them.
              </p>

              {/* Badges */}
              <div className="flex flex-wrap gap-4">
                {["Privacy First", "High Availability", "Smart Context"].map((badge, idx) => (
                  <span key={idx} className="bg-gold-dim border border-gold/30 text-gold text-[0.75rem] font-medium px-4 py-2 rounded-md uppercase tracking-[0.05em]">
                    {badge}
                  </span>
                ))}
              </div>
            </FadeUp>
          </div>
        </div>
      </section>

      {/* SECTION 5: REVIEWS */}
      <section id="reviews" className="py-[120px] bg-page overflow-hidden transition-colors duration-300">
         <FadeUp>
            <div className="text-center mb-12">
              <h2 className="text-[2.5rem] font-semibold text-text-primary">User Reviews</h2>
              <div className="w-[60px] h-[3px] bg-gold mx-auto mt-4 mb-12"></div>
            </div>
          </FadeUp>

          <div className="flex gap-6 overflow-x-auto pb-5 px-6 max-w-[1200px] mx-auto snap-x snap-mandatory no-scrollbar">
            {[
              {
                quote: "This AI assistant has completely transformed how I manage my daily schedule. The voice commands are incredibly accurate.",
                name: "Priya S.",
                title: "Verified AI User"
              },
              {
                quote: "Finally, an automation tool that is intuitive. I've saved hours every week by letting it handle my routine emails.",
                name: "Marcus C.",
                title: "Verified AI User"
              },
              {
                quote: "The smart answers are spot on. It feels like having a research assistant available 24/7.",
                name: "David M.",
                title: "Verified AI User"
              },
              {
                quote: "I love the custom commands feature. It feels tailored exactly to my workflow.",
                name: "Aisha J.",
                title: "Verified AI User"
              },
              {
                quote: "Secure, fast, and reliable. Exactly what I needed for my business operations.",
                name: "Robert K.",
                title: "Verified AI User"
              }
            ].map((testi, idx) => (
              <div key={idx} className="w-[350px] flex-shrink-0 bg-surface border border-border rounded-xl p-7 snap-start relative">
                <div className="text-gold/30 text-[3rem] font-serif leading-none absolute top-4 left-6">"</div>
                <p className="text-[1rem] text-text-secondary italic leading-[1.7] mt-6 mb-8 relative z-10">{testi.quote}</p>
                <div>
                  <div className="text-text-primary font-semibold">{testi.name}</div>
                  <div className="text-[0.875rem] text-gold">{testi.title}</div>
                </div>
              </div>
            ))}
          </div>
      </section>

      {/* SECTION 6: COMMUNITY FEEDBACK */}
      <section className="py-[120px] bg-surface relative px-6 transition-colors duration-300">
        <div className="max-w-[600px] mx-auto">
          <FadeUp>
            <div className="text-center mb-12">
              <h2 className="text-[2.5rem] font-semibold text-text-primary">Share Your Experience</h2>
              <p className="text-[1rem] text-text-secondary mt-4">Help us improve by sharing your feedback.</p>
            </div>

            <form onSubmit={(e) => e.preventDefault()} className="text-left bg-page p-8 rounded-2xl border border-border">
              <div className="mb-5">
                <label className="block text-[0.875rem] text-text-secondary mb-2">Name</label>
                <input type="text" className="w-full bg-surface border border-border rounded-lg px-4 py-[14px] text-text-primary text-[1rem] focus:outline-none focus:border-gold focus:ring-4 focus:ring-gold/20 transition-all" />
              </div>

              <div className="mb-5">
                <label className="block text-[0.875rem] text-text-secondary mb-2">Email (Optional)</label>
                <input type="email" className="w-full bg-surface border border-border rounded-lg px-4 py-[14px] text-text-primary text-[1rem] focus:outline-none focus:border-gold focus:ring-4 focus:ring-gold/20 transition-all" />
              </div>

              <div className="mb-5">
                <label className="block text-[0.875rem] text-text-secondary mb-2">Rating (1-5)</label>
                <select className="w-full bg-surface border border-border rounded-lg px-4 py-[14px] text-text-primary text-[1rem] focus:outline-none focus:border-gold focus:ring-4 focus:ring-gold/20 transition-all">
                  <option className="bg-surface">5 Stars</option>
                  <option className="bg-surface">4 Stars</option>
                  <option className="bg-surface">3 Stars</option>
                  <option className="bg-surface">2 Stars</option>
                  <option className="bg-surface">1 Star</option>
                </select>
              </div>

              <div className="mb-6">
                <label className="block text-[0.875rem] text-text-secondary mb-2">Comment</label>
                <textarea className="w-full min-h-[120px] resize-y bg-surface border border-border rounded-lg px-4 py-[14px] text-text-primary text-[1rem] focus:outline-none focus:border-gold focus:ring-4 focus:ring-gold/20 transition-all"></textarea>
              </div>

              <button className="w-full bg-gold text-page font-semibold py-[14px] rounded-lg text-[1rem] hover:shadow-[0_0_30px_rgba(212,175,55,0.4)] transition-all">
                Submit Feedback
              </button>
              
              <p className="text-[0.75rem] text-text-tertiary mt-4 text-center">
                Comments with 4–5 star ratings are automatically added to the Reviews section.
              </p>
            </form>
          </FadeUp>
        </div>
      </section>

      {/* SECTION 7: CTA */}
      <section className="py-[160px] bg-page relative flex justify-center items-center transition-colors duration-300">
        <div className="absolute inset-0 bg-gold-radial pointer-events-none"></div>
        <FadeUp className="relative z-10 max-w-[600px] text-center px-6">
          <h2 className="text-[2.5rem] font-semibold text-text-primary mb-4">Ready to Experience Your Own AI Assistant?</h2>
          <p className="text-[1.125rem] text-text-secondary mb-8">
            Start using an AI that works the way you do.
          </p>
          <Link to="/register" className="inline-block bg-gold text-page text-[1.125rem] font-semibold px-12 py-[18px] rounded-lg hover:shadow-[0_0_40px_rgba(212,175,55,0.5)] transition-all duration-300">
            Get Started Now
          </Link>
          <p className="text-[0.875rem] text-text-tertiary mt-4">Free 14-day trial</p>
        </FadeUp>
      </section>
    </>
  );
};

export default Home;