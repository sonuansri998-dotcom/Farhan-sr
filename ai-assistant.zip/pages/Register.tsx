import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FadeUp } from '../components/Animations';

const Register: React.FC = () => {
  const navigate = useNavigate();

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, registration logic would go here
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* LEFT COLUMN - Identical to Login */}
      <div className="hidden md:flex md:w-1/2 bg-[#0a0a12] relative flex-col items-center justify-center p-12 overflow-hidden bg-dot-pattern">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a12] to-[#050508] z-0 opacity-90"></div>
        <FadeUp className="relative z-10 flex flex-col items-center">
           <div className="w-[350px] h-[450px] bg-white/[0.02] border-2 border-dashed border-gold/30 rounded-2xl flex items-center justify-center shadow-[0_0_80px_rgba(212,175,55,0.15)]">
             <span className="text-white/30">AI Visual</span>
           </div>
           <div className="mt-6 text-center">
              <div className="text-xl tracking-tight mb-2">
                <span className="font-bold text-gold">AI</span>
                <span className="text-white font-normal">Assistant</span>
              </div>
              <p className="text-[0.875rem] text-white/50">Intelligent Automation</p>
           </div>
        </FadeUp>
      </div>

      {/* RIGHT COLUMN */}
      <div className="w-full md:w-1/2 bg-page flex items-center justify-center p-12">
        <FadeUp className="w-full max-w-[400px]">
          <h1 className="text-[2rem] font-bold text-white mb-2">Create Account</h1>
          <p className="text-[1rem] text-text-secondary mb-8">Start your AI automation journey today</p>

          <form onSubmit={handleRegister}>
            <div className="mb-5">
              <label className="block text-[0.875rem] text-white/80 mb-2">Full Name</label>
              <input type="text" className="w-full bg-white/[0.03] border border-white/10 rounded-lg px-4 py-[14px] text-white text-[1rem] focus:outline-none focus:border-gold focus:ring-4 focus:ring-gold/20 transition-all" />
            </div>

            <div className="mb-5">
              <label className="block text-[0.875rem] text-white/80 mb-2">Email</label>
              <input type="email" className="w-full bg-white/[0.03] border border-white/10 rounded-lg px-4 py-[14px] text-white text-[1rem] focus:outline-none focus:border-gold focus:ring-4 focus:ring-gold/20 transition-all" />
            </div>
            
            <div className="mb-5">
              <label className="block text-[0.875rem] text-white/80 mb-2">Password</label>
              <input type="password" className="w-full bg-white/[0.03] border border-white/10 rounded-lg px-4 py-[14px] text-white text-[1rem] focus:outline-none focus:border-gold focus:ring-4 focus:ring-gold/20 transition-all" />
            </div>

             <div className="mb-5">
              <label className="block text-[0.875rem] text-white/80 mb-2">Confirm Password</label>
              <input type="password" className="w-full bg-white/[0.03] border border-white/10 rounded-lg px-4 py-[14px] text-white text-[1rem] focus:outline-none focus:border-gold focus:ring-4 focus:ring-gold/20 transition-all" />
            </div>

            <div className="flex items-start mb-6">
              <input type="checkbox" className="mt-1 mr-3 accent-gold" />
              <label className="text-[0.875rem] text-text-secondary">
                I agree to the <a href="#" className="text-gold hover:underline">Terms of Service</a> and <a href="#" className="text-gold hover:underline">Privacy Policy</a>
              </label>
            </div>

            <button className="w-full bg-gold text-page font-semibold py-[14px] rounded-lg text-[1rem] hover:shadow-[0_0_30px_rgba(212,175,55,0.4)] transition-all mb-6">
              Create Account
            </button>

            <div className="flex items-center mb-6">
              <div className="h-px bg-white/10 flex-grow"></div>
              <span className="px-4 text-[0.875rem] text-white/40">or</span>
              <div className="h-px bg-white/10 flex-grow"></div>
            </div>

            <button type="button" className="w-full bg-transparent border border-white/20 text-white py-[14px] rounded-lg hover:bg-white/5 transition-all mb-8">
              Continue with Google
            </button>

            <p className="text-center text-[0.875rem] text-text-secondary">
              Already have an account? <Link to="/login" className="text-gold hover:underline">Sign In</Link>
            </p>
          </form>
        </FadeUp>
      </div>
    </div>
  );
};

export default Register;