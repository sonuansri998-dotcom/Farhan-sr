import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-surface border-t border-border py-12 transition-colors duration-300">
      <div className="max-w-[1200px] mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
        {/* Left: Logo */}
        <div className="text-center md:text-left">
          <Link to="/" className="text-xl tracking-tight">
            <span className="font-bold text-gold">AI</span>
            <span className="text-text-primary font-normal">Assistant</span>
          </Link>
        </div>

        {/* Center: Links */}
        <div className="flex flex-wrap justify-center gap-6 text-[0.875rem] text-text-secondary">
          <a href="/#features" className="hover:text-text-primary transition-colors">Features</a>
          <a href="/#about" className="hover:text-text-primary transition-colors">About</a>
          <a href="/#reviews" className="hover:text-text-primary transition-colors">Reviews</a>
          <Link to="/contact" className="hover:text-text-primary transition-colors">Support</Link>
          <a href="#" className="hover:text-text-primary transition-colors">Privacy</a>
          <a href="#" className="hover:text-text-primary transition-colors">Terms</a>
        </div>

        {/* Right: Copyright */}
        <div className="text-center md:text-right text-[0.875rem] text-text-tertiary">
          © 2025 AI Assistant. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;