import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

const Navigation: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, hash: string) => {
    // If we are on the home page, just let the anchor default behavior (smooth scroll) happen
    if (location.pathname === '/') {
      return;
    }
    // If we are on another page, prevent default and navigate to home with hash
    e.preventDefault();
    navigate('/' + hash);
  };

  return (
    <nav className="sticky top-0 z-50 h-[72px] w-full bg-page/80 backdrop-blur-xl border-b border-border transition-colors duration-300">
      <div className="max-w-[1200px] mx-auto px-6 h-full flex items-center justify-between">
        {/* Left: Logo */}
        <Link to="/" className="text-xl tracking-tight group">
          <span className="font-bold text-gold group-hover:text-gold/80 transition-colors">AI</span>
          <span className="text-text-primary font-normal ml-1">Assistant</span>
        </Link>

        {/* Center: Links */}
        <div className="hidden md:flex items-center gap-8">
          {[
            { name: 'Features', hash: '#features' },
            { name: 'About', hash: '#about' },
            { name: 'Reviews', hash: '#reviews' },
          ].map((link) => (
            <a
              key={link.name}
              href={link.hash}
              onClick={(e) => handleNavClick(e, link.hash)}
              className="text-[0.875rem] text-text-secondary hover:text-gold transition-colors duration-300 cursor-pointer font-medium"
            >
              {link.name}
            </a>
          ))}
        </div>

        {/* Right: CTA Buttons */}
        <div className="flex items-center gap-4">
          <Link
            to="/login"
            className="bg-gold text-page px-6 py-3 rounded-lg text-sm font-medium hover:brightness-110 hover:shadow-[0_0_20px_rgba(212,175,55,0.3)] transition-all duration-300"
          >
            Login
          </Link>
          <Link
            to="/register"
            className="bg-gold text-page px-6 py-3 rounded-lg text-sm font-medium hover:brightness-110 hover:shadow-[0_0_20px_rgba(212,175,55,0.3)] transition-all duration-300"
          >
            Get Started
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;