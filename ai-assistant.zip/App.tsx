import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import About from './pages/About';
import Contact from './pages/Contact';
import Dashboard from './pages/Dashboard';
import Navigation from './components/Navigation';
import Footer from './components/Footer';

const ScrollToTop = () => {
  const { pathname, hash } = useLocation();

  React.useEffect(() => {
    // Only scroll to top if there is no hash
    if (!hash) {
      window.scrollTo(0, 0);
    }
  }, [pathname, hash]);

  return null;
};

const Layout: React.FC<{ children: React.ReactNode; hideNavFooter?: boolean }> = ({ children, hideNavFooter }) => {
  return (
    <div className="min-h-screen flex flex-col bg-page text-text-primary font-sans selection:bg-gold selection:text-black">
      {!hideNavFooter && <Navigation />}
      <main className="flex-grow">
        {children}
      </main>
      {!hideNavFooter && <Footer />}
    </div>
  );
};

const App: React.FC = () => {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  };

  useEffect(() => {
    if (theme === 'light') {
      document.body.classList.add('light');
    } else {
      document.body.classList.remove('light');
    }
  }, [theme]);

  return (
    <HashRouter>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Layout><Home /></Layout>} />
        <Route path="/about" element={<Layout><About /></Layout>} />
        <Route path="/contact" element={<Layout><Contact /></Layout>} />
        <Route path="/login" element={<Layout hideNavFooter><Login /></Layout>} />
        <Route path="/register" element={<Layout hideNavFooter><Register /></Layout>} />
        <Route path="/dashboard" element={<Dashboard currentTheme={theme} onToggleTheme={toggleTheme} />} />
      </Routes>
    </HashRouter>
  );
};

export default App;