import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

// --- MOCK DATA ---
const PRODUCT_STATS = [
  { id: 'total', label: 'Total Features', value: '12', desc: 'Core Modules', icon: '📦' },
  { id: 'stable', label: 'Stable Features', value: '8', desc: 'Production Ready', icon: '🚀' },
  { id: 'dev', label: 'Coming Soon', value: '4', desc: 'In Development', icon: '🧪' },
];

const FEATURES_LIST = [
  { id: 1, name: 'Natural Language Processing', status: 'Stable', category: 'Core' },
  { id: 2, name: 'Task Automation Engine', status: 'Stable', category: 'Productivity' },
  { id: 3, name: 'Real-time Search Grounding', status: 'Stable', category: 'Intelligence' },
  { id: 4, name: 'Voice Synthesis (TTS)', status: 'Stable', category: 'Voice' },
  { id: 5, name: 'Speech Recognition', status: 'Stable', category: 'Voice' },
  { id: 6, name: 'Advanced Reasoning', status: 'Stable', category: 'Core' },
  { id: 7, name: 'Document Analysis', status: 'Stable', category: 'Productivity' },
  { id: 8, name: 'Email Integration', status: 'Stable', category: 'Connectivity' },
  { id: 9, name: 'Vision / Image Analysis', status: 'Coming Soon', category: 'Vision' },
  { id: 10, name: 'Code Generation Agent', status: 'Coming Soon', category: 'Dev' },
  { id: 11, name: 'Multi-Modal Memory', status: 'Coming Soon', category: 'Memory' },
  { id: 12, name: 'Custom Plugin API', status: 'Coming Soon', category: 'Dev' },
];

const HISTORY_PURCHASES = [
  { id: 101, item: 'Enterprise License', date: 'Oct 24, 2024', amount: '$499.00', status: 'Paid' },
  { id: 102, item: 'Additional User Seat', date: 'Nov 02, 2024', amount: '$49.00', status: 'Paid' },
];

const HISTORY_REPORTS = [
  { id: 201, title: 'Q3 Usage Analysis', date: 'Oct 01, 2024', type: 'PDF' },
  { id: 202, title: 'System Performance Log', date: 'Oct 15, 2024', type: 'CSV' },
  { id: 203, title: 'Security Audit Report', date: 'Nov 01, 2024', type: 'PDF' },
];

interface DashboardProps {
  currentTheme: 'dark' | 'light';
  onToggleTheme: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ currentTheme, onToggleTheme }) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [featureFilter, setFeatureFilter] = useState('All');
  
  // Handlers
  const handleLogout = () => {
    navigate('/');
  };

  // --- RENDER VIEWS ---

  const renderOverview = () => (
    <div className="space-y-8">
      {/* Product Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {PRODUCT_STATS.map((stat, idx) => (
          <motion.div
            key={stat.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            whileHover={{ scale: 1.02 }}
            className="bg-surface border border-border p-8 rounded-xl relative overflow-hidden group hover:border-gold/30 transition-all cursor-default"
          >
            <div className="flex justify-between items-start mb-4">
               <div className="text-3xl">{stat.icon}</div>
               <div className="text-[2.5rem] font-bold text-text-primary leading-none">{stat.value}</div>
            </div>
            <div>
              <div className="text-lg font-semibold text-text-primary">{stat.label}</div>
              <div className="text-sm text-text-tertiary">{stat.desc}</div>
            </div>
            <div className="absolute top-0 right-0 w-32 h-32 bg-gold/5 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>
          </motion.div>
        ))}
      </div>

      {/* Info Block */}
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        transition={{ delay: 0.3 }}
        className="bg-surface border border-border rounded-xl p-10 flex flex-col md:flex-row items-center gap-10"
      >
        <div className="flex-1">
          <h2 className="text-2xl font-bold text-text-primary mb-4">Why Aris is Different</h2>
          <p className="text-text-secondary leading-relaxed mb-6">
            Aris operates as a standalone, privacy-first AI engine. Unlike generic cloud wrappers, Aris is designed to be your personal intelligent layer, capable of understanding context without compromising your data sovereignty.
          </p>
          <div className="flex flex-wrap gap-3">
             {['Privacy-First', 'No Dependencies', 'Enterprise Grade', 'Low Latency'].map(tag => (
               <span key={tag} className="px-3 py-1 rounded-full bg-gold-dim border border-gold/20 text-gold text-xs font-medium uppercase tracking-wider">
                 {tag}
               </span>
             ))}
          </div>
        </div>
        <div className="w-full md:w-1/3 flex justify-center">
           <div className="w-48 h-48 rounded-full border-4 border-gold/20 flex items-center justify-center relative">
              <div className="absolute inset-0 border-t-4 border-gold rounded-full animate-spin"></div>
              <span className="text-2xl font-bold text-text-primary">Aris</span>
           </div>
        </div>
      </motion.div>
    </div>
  );

  const renderFeatures = () => {
    const filtered = FEATURES_LIST.filter(f => {
      if (featureFilter === 'All') return true;
      if (featureFilter === 'Stable') return f.status === 'Stable';
      if (featureFilter === 'Coming Soon') return f.status === 'Coming Soon';
      return true;
    });

    return (
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-semibold text-text-primary">System Features</h2>
          <div className="flex gap-2 bg-surface border border-border p-1 rounded-lg">
            {['All', 'Stable', 'Coming Soon'].map(filter => (
              <button
                key={filter}
                onClick={() => setFeatureFilter(filter)}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${featureFilter === filter ? 'bg-gold text-surface shadow-sm' : 'text-text-secondary hover:text-text-primary'}`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence mode="popLayout">
            {filtered.map((feature) => (
              <motion.div
                key={feature.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                whileHover={{ y: -4, borderColor: 'rgba(212,175,55,0.4)' }}
                className="bg-surface border border-border p-6 rounded-xl relative group"
              >
                <div className="flex justify-between items-start mb-4">
                  <span className="text-xs font-semibold text-text-tertiary uppercase tracking-wider">{feature.category}</span>
                  <span className={`w-2 h-2 rounded-full ${feature.status === 'Stable' ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' : 'bg-blue-500'}`}></span>
                </div>
                <h3 className="text-lg font-medium text-text-primary mb-2">{feature.name}</h3>
                <div className={`text-xs font-medium px-2 py-1 rounded inline-block ${feature.status === 'Stable' ? 'bg-green-500/10 text-green-500' : 'bg-blue-500/10 text-blue-400'}`}>
                  {feature.status}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    );
  };

  const renderHistory = () => (
    <div className="space-y-8 max-w-4xl">
      
      {/* PURCHASES */}
      <section>
        <h2 className="text-xl font-semibold text-text-primary mb-4">Purchases</h2>
        <div className="space-y-4">
          {HISTORY_PURCHASES.map((purchase) => (
            <div key={purchase.id} className="relative bg-surface border border-border rounded-xl p-5 overflow-hidden group">
              {/* Shimmer Effect */}
              <div className="absolute inset-0 w-full h-full pointer-events-none">
                 <div className="w-1/2 h-full bg-gradient-to-r from-transparent via-white/[0.05] to-transparent skew-x-12 animate-shimmer absolute top-0 left-0"></div>
              </div>
              
              <div className="relative z-10 flex justify-between items-center">
                <div>
                  <div className="text-lg font-medium text-text-primary group-hover:text-gold transition-colors">{purchase.item}</div>
                  <div className="text-sm text-text-secondary">{purchase.date}</div>
                </div>
                <div className="text-right">
                   <div className="text-lg font-bold text-text-primary">{purchase.amount}</div>
                   <div className="text-xs text-green-500 uppercase font-medium tracking-wider">{purchase.status}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* REPORTS */}
      <section>
        <h2 className="text-xl font-semibold text-text-primary mb-4">Reports</h2>
        <div className="grid gap-3">
           {HISTORY_REPORTS.map((report) => (
             <motion.div 
              key={report.id}
              whileHover={{ scale: 1.01 }}
              className="group bg-surface border border-border rounded-xl p-4 flex items-center justify-between cursor-pointer relative"
             >
               <div className="flex items-center gap-4">
                 <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center text-text-secondary group-hover:bg-gold group-hover:text-black transition-colors">
                   <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                 </div>
                 <div>
                   <div className="font-medium text-text-primary">{report.title}</div>
                   <div className="text-sm text-text-tertiary">{report.date}</div>
                 </div>
               </div>
               <div className="text-xs font-bold text-text-tertiary border border-border px-2 py-1 rounded">
                 {report.type}
               </div>

               {/* Hover Preview Tooltip */}
               <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 w-64 bg-elevated border border-border p-3 rounded-lg shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20">
                 <div className="text-xs font-semibold text-text-primary mb-1">Preview</div>
                 <div className="h-16 bg-white/5 rounded w-full"></div>
                 <div className="h-2 bg-white/5 rounded w-3/4 mt-2"></div>
               </div>
             </motion.div>
           ))}
        </div>
      </section>
    </div>
  );

  const renderSettings = () => (
    <div className="max-w-2xl">
      <h2 className="text-2xl font-semibold text-text-primary mb-8">Product Settings</h2>

      <div className="space-y-6">
        {/* Theme Toggle */}
        <div className="bg-surface border border-border rounded-xl p-6 flex items-center justify-between">
          <div>
             <div className="text-lg font-medium text-text-primary">Theme Appearance</div>
             <div className="text-sm text-text-secondary">Switch between light and dark mode</div>
          </div>
          <button 
            onClick={onToggleTheme}
            className="w-32 py-2.5 rounded-lg bg-elevated border border-border text-text-primary font-medium hover:bg-gold hover:text-black hover:border-gold transition-all duration-300"
          >
             {currentTheme === 'dark' ? 'Light Mode' : 'Dark Mode'}
          </button>
        </div>

        {/* Notifications */}
        <div className="bg-surface border border-border rounded-xl p-6 flex items-center justify-between">
          <div>
             <div className="text-lg font-medium text-text-primary">Email Notifications</div>
             <div className="text-sm text-text-secondary">Receive updates about new Aris features</div>
          </div>
          <div className="w-12 h-6 bg-gold rounded-full relative cursor-pointer">
             <div className="absolute right-1 top-1 w-4 h-4 bg-black rounded-full shadow-sm"></div>
          </div>
        </div>

        {/* Account */}
        <div className="bg-surface border border-border rounded-xl p-6">
          <h3 className="text-lg font-medium text-text-primary mb-4">Account & Access</h3>
          <div className="space-y-4">
             <div>
               <label className="block text-xs font-semibold text-text-tertiary uppercase tracking-wider mb-1">Email Address</label>
               <div className="text-text-primary text-lg">demo@aris.ai</div>
             </div>
             <div>
               <label className="block text-xs font-semibold text-text-tertiary uppercase tracking-wider mb-1">Subscription</label>
               <div className="flex items-center gap-2">
                 <span className="text-text-primary text-lg">Enterprise Plan</span>
                 <span className="bg-green-500/10 text-green-500 text-xs px-2 py-0.5 rounded border border-green-500/20">Active</span>
               </div>
             </div>
             <button className="mt-2 text-sm text-gold hover:underline">Manage Subscription</button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-page text-text-primary font-sans flex overflow-hidden transition-colors duration-300">
      
      {/* SIDEBAR - FIXED */}
      <aside className="w-64 bg-surface border-r border-border flex-shrink-0 hidden md:flex flex-col z-30 transition-colors duration-300">
        <div className="h-20 flex items-center px-8 border-b border-border">
          <Link to="/" className="text-xl tracking-tight">
            <span className="font-bold text-gold">Aris</span>
            <span className="text-text-primary font-normal ml-1">Dashboard</span>
          </Link>
        </div>

        <nav className="flex-grow p-6 space-y-2">
          {['Overview', 'Features', 'History', 'Settings'].map((item) => (
            <button
              key={item}
              onClick={() => setActiveTab(item.toLowerCase())}
              className={`w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-all duration-300 flex items-center justify-between ${
                activeTab === item.toLowerCase() 
                  ? 'bg-gold/10 text-gold border border-gold/20' 
                  : 'text-text-secondary hover:text-text-primary hover:bg-white/5 border border-transparent'
              }`}
            >
              {item}
              {activeTab === item.toLowerCase() && <motion.div layoutId="active-indicator" className="w-1.5 h-1.5 rounded-full bg-gold" />}
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-border">
          <button onClick={handleLogout} className="flex items-center text-sm text-text-tertiary hover:text-text-primary transition-colors w-full">
            <svg className="w-5 h-5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
            Sign Out
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-1 flex flex-col h-screen overflow-y-auto relative no-scrollbar bg-page transition-colors duration-300">
        {/* HEADER */}
        <header className="h-20 bg-page/80 backdrop-blur-xl border-b border-border flex items-center justify-between px-8 sticky top-0 z-20 transition-colors duration-300">
          <div>
            <h1 className="text-xl font-semibold text-text-primary capitalize">{activeTab}</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-surface border border-border flex items-center justify-center text-gold font-bold shadow-sm">
              U
            </div>
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'overview' && renderOverview()}
              {activeTab === 'features' && renderFeatures()}
              {activeTab === 'history' && renderHistory()}
              {activeTab === 'settings' && renderSettings()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;